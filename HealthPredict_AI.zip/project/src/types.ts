export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: 'male' | 'female' | 'other';
  location: string;
  medicalHistory: string[];
  symptoms: string[];
}

export interface Prediction {
  disease: string;
  probability: number;
  urgency: 'low' | 'medium' | 'high';
  recommendedAction: string;
}

export interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  startDate: string;
  endDate: string;
  timeSlots: string[];
}

export interface Appointment {
  id: string;
  doctorName: string;
  specialization: string;
  date: string;
  time: string;
  status: 'upcoming' | 'completed' | 'cancelled';
  notes?: string;
}

export interface DietPlan {
  id: string;
  name: string;
  type: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  time: string;
  items: string[];
  calories: number;
  restrictions?: string[];
}