import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Profile } from './components/Profile';
import { Prediction } from './components/Prediction';
import { Medicines } from './components/Medicines';
import { Appointments } from './components/Appointments';
import { DietPlan } from './components/DietPlan';
import { AIAssistant } from './components/AIAssistant';

function App() {
  const [activeTab, setActiveTab] = useState('prediction');

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="container mx-auto py-8">
        {activeTab === 'prediction' && <Prediction />}
        {activeTab === 'medicines' && <Medicines />}
        {activeTab === 'appointments' && <Appointments />}
        {activeTab === 'diet' && <DietPlan />}
        {activeTab === 'profile' && <Profile />}
      </main>
      <AIAssistant />
    </div>
  );
}

export default App;