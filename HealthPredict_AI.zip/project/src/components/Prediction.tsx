import React, { useState } from 'react';
import { AlertCircle, CheckCircle2 } from 'lucide-react';
import type { Prediction } from '../types';

const commonSymptoms = [
  'Fever', 'Cough', 'Fatigue', 'Shortness of breath', 'Headache',
  'Body aches', 'Sore throat', 'Nausea', 'Diarrhea', 'Loss of taste/smell'
];

export function Prediction() {
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [prediction, setPrediction] = useState<Prediction | null>(null);

  const toggleSymptom = (symptom: string) => {
    setSelectedSymptoms(prev =>
      prev.includes(symptom)
        ? prev.filter(s => s !== symptom)
        : [...prev, symptom]
    );
  };

  const getPrediction = () => {
    // Simulated AI prediction
    const mockPredictions: Prediction[] = [
      {
        disease: 'Common Cold',
        probability: 0.85,
        urgency: 'low',
        recommendedAction: 'Rest and monitor symptoms. Schedule virtual consultation if symptoms worsen.'
      },
      {
        disease: 'COVID-19',
        probability: 0.65,
        urgency: 'high',
        recommendedAction: 'Immediate isolation and testing required. Schedule urgent field visit.'
      },
      {
        disease: 'Seasonal Flu',
        probability: 0.75,
        urgency: 'medium',
        recommendedAction: 'Schedule teleconsultation within 24 hours.'
      }
    ];

    const randomIndex = Math.floor(Math.random() * mockPredictions.length);
    setPrediction(mockPredictions[randomIndex]);
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Symptom Analysis</h2>
        
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Select Your Symptoms</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {commonSymptoms.map(symptom => (
              <button
                key={symptom}
                onClick={() => toggleSymptom(symptom)}
                className={`p-3 rounded-lg text-sm font-medium transition ${
                  selectedSymptoms.includes(symptom)
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {symptom}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={getPrediction}
          disabled={selectedSymptoms.length === 0}
          className="w-full py-3 px-4 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Analyze Symptoms
        </button>

        {prediction && (
          <div className="mt-8 p-6 bg-gray-50 rounded-xl">
            <div className="flex items-start space-x-4">
              {prediction.urgency === 'high' ? (
                <AlertCircle className="w-6 h-6 text-red-500 flex-shrink-0" />
              ) : (
                <CheckCircle2 className="w-6 h-6 text-green-500 flex-shrink-0" />
              )}
              <div>
                <h3 className="text-xl font-bold text-gray-800">
                  Predicted Condition: {prediction.disease}
                </h3>
                <div className="mt-2 space-y-2">
                  <p className="text-gray-600">
                    Confidence: {(prediction.probability * 100).toFixed(1)}%
                  </p>
                  <p className="text-gray-600">
                    Urgency: <span className={`font-medium ${
                      prediction.urgency === 'high' ? 'text-red-600' :
                      prediction.urgency === 'medium' ? 'text-yellow-600' :
                      'text-green-600'
                    }`}>
                      {prediction.urgency.toUpperCase()}
                    </span>
                  </p>
                  <p className="text-gray-600">
                    Recommended Action: {prediction.recommendedAction}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}