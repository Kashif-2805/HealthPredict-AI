import React, { useState } from 'react';
import { Clock, Plus, Bell } from 'lucide-react';
import type { Medication } from '../types';

const mockMedications: Medication[] = [
  {
    id: '1',
    name: 'Amoxicillin',
    dosage: '500mg',
    frequency: 'Twice daily',
    startDate: '2024-03-01',
    endDate: '2024-03-14',
    timeSlots: ['09:00', '21:00']
  },
  {
    id: '2',
    name: 'Paracetamol',
    dosage: '650mg',
    frequency: 'As needed',
    startDate: '2024-03-01',
    endDate: '2024-03-07',
    timeSlots: ['08:00', '14:00', '20:00']
  }
];

export function Medicines() {
  const [medications] = useState<Medication[]>(mockMedications);
  const [showAlarmModal, setShowAlarmModal] = useState(false);

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Medicine Tracker</h2>
        <button className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition">
          <Plus className="w-5 h-5" />
          <span>Add Medicine</span>
        </button>
      </div>

      <div className="grid gap-6">
        {medications.map((med) => (
          <div key={med.id} className="bg-white rounded-xl shadow-md p-6">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-xl font-semibold text-gray-800">{med.name}</h3>
                <p className="text-gray-600">{med.dosage} - {med.frequency}</p>
              </div>
              <button
                onClick={() => setShowAlarmModal(true)}
                className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition"
              >
                <Bell className="w-5 h-5" />
              </button>
            </div>
            
            <div className="mt-4">
              <div className="flex items-center space-x-2 text-gray-600">
                <Clock className="w-4 h-4" />
                <span>Time slots:</span>
              </div>
              <div className="mt-2 flex flex-wrap gap-2">
                {med.timeSlots.map((time, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-sm"
                  >
                    {time}
                  </span>
                ))}
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-gray-100">
              <div className="flex justify-between text-sm text-gray-600">
                <span>Started: {med.startDate}</span>
                <span>Ends: {med.endDate}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showAlarmModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <h3 className="text-xl font-bold mb-4">Set Medicine Reminder</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Time</label>
                <input
                  type="time"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Repeat</label>
                <select className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                  <option>Daily</option>
                  <option>Weekly</option>
                  <option>Custom</option>
                </select>
              </div>
              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => setShowAlarmModal(false)}
                  className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  onClick={() => setShowAlarmModal(false)}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition"
                >
                  Set Alarm
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}