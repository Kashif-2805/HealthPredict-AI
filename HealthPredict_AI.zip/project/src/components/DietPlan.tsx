import React from 'react';
import { Clock, Plus } from 'lucide-react';
import type { DietPlan } from '../types';

const mockDietPlans: DietPlan[] = [
  {
    id: '1',
    name: 'Breakfast',
    type: 'breakfast',
    time: '08:00',
    items: ['Oatmeal with fruits', 'Greek yogurt', 'Green tea'],
    calories: 350,
    restrictions: ['Low sugar', 'High fiber']
  },
  {
    id: '2',
    name: 'Lunch',
    type: 'lunch',
    time: '13:00',
    items: ['Grilled chicken breast', 'Quinoa', 'Steamed vegetables'],
    calories: 450,
    restrictions: ['Low carb']
  },
  {
    id: '3',
    name: 'Dinner',
    type: 'dinner',
    time: '19:00',
    items: ['Baked fish', 'Brown rice', 'Mixed salad'],
    calories: 400,
    restrictions: ['Low fat']
  }
];

export function DietPlan() {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Diet Plan</h2>
        <button className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition">
          <Plus className="w-5 h-5" />
          <span>Add Meal</span>
        </button>
      </div>

      <div className="grid gap-6">
        {mockDietPlans.map((meal) => (
          <div key={meal.id} className="bg-white rounded-xl shadow-md p-6">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-xl font-semibold text-gray-800">{meal.name}</h3>
                <div className="flex items-center space-x-2 text-gray-600 mt-1">
                  <Clock className="w-4 h-4" />
                  <span>{meal.time}</span>
                </div>
              </div>
              <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm">
                {meal.calories} kcal
              </span>
            </div>

            <div className="mt-4">
              <h4 className="font-medium text-gray-700 mb-2">Meal Items:</h4>
              <ul className="space-y-2">
                {meal.items.map((item, index) => (
                  <li key={index} className="flex items-center space-x-2">
                    <span className="w-2 h-2 bg-indigo-500 rounded-full"></span>
                    <span className="text-gray-600">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {meal.restrictions && (
              <div className="mt-4 pt-4 border-t border-gray-100">
                <h4 className="font-medium text-gray-700 mb-2">Dietary Notes:</h4>
                <div className="flex flex-wrap gap-2">
                  {meal.restrictions.map((restriction, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-sm"
                    >
                      {restriction}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}