import React, { useState } from 'react';
import { Calendar, Clock, MapPin, Plus } from 'lucide-react';
import type { Appointment } from '../types';

const mockAppointments: Appointment[] = [
  {
    id: '1',
    doctorName: 'Dr. Sarah Johnson',
    specialization: 'Cardiologist',
    date: '2024-03-15',
    time: '10:00',
    status: 'upcoming',
    notes: 'Regular checkup'
  },
  {
    id: '2',
    doctorName: 'Dr. Michael Chen',
    specialization: 'General Physician',
    date: '2024-03-01',
    time: '15:30',
    status: 'completed',
    notes: 'Follow-up appointment'
  }
];

export function Appointments() {
  const [appointments] = useState<Appointment[]>(mockAppointments);
  const [filter, setFilter] = useState<'all' | 'upcoming' | 'completed'>('all');

  const filteredAppointments = appointments.filter(apt => 
    filter === 'all' ? true : apt.status === filter
  );

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Appointments</h2>
        <button className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition">
          <Plus className="w-5 h-5" />
          <span>Book Appointment</span>
        </button>
      </div>

      <div className="flex space-x-4 mb-6">
        {(['all', 'upcoming', 'completed'] as const).map((status) => (
          <button
            key={status}
            onClick={() => setFilter(status)}
            className={`px-4 py-2 rounded-lg transition ${
              filter === status
                ? 'bg-indigo-600 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </button>
        ))}
      </div>

      <div className="grid gap-6">
        {filteredAppointments.map((apt) => (
          <div
            key={apt.id}
            className={`bg-white rounded-xl shadow-md p-6 border-l-4 ${
              apt.status === 'upcoming' ? 'border-indigo-500' : 'border-green-500'
            }`}
          >
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-xl font-semibold text-gray-800">{apt.doctorName}</h3>
                <p className="text-gray-600">{apt.specialization}</p>
              </div>
              <span
                className={`px-3 py-1 rounded-full text-sm ${
                  apt.status === 'upcoming'
                    ? 'bg-indigo-100 text-indigo-700'
                    : 'bg-green-100 text-green-700'
                }`}
              >
                {apt.status.charAt(0).toUpperCase() + apt.status.slice(1)}
              </span>
            </div>

            <div className="mt-4 space-y-2">
              <div className="flex items-center space-x-2 text-gray-600">
                <Calendar className="w-4 h-4" />
                <span>{apt.date}</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-600">
                <Clock className="w-4 h-4" />
                <span>{apt.time}</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-600">
                <MapPin className="w-4 h-4" />
                <span>City Medical Center</span>
              </div>
            </div>

            {apt.notes && (
              <div className="mt-4 pt-4 border-t border-gray-100">
                <p className="text-gray-600">{apt.notes}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}