import React from 'react';
import { UserCircle2, Activity, Menu, Calendar, Pill as Pills, Apple, Bell, Search, Mic, Camera } from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export function Navbar({ activeTab, setActiveTab }: NavbarProps) {
  return (
    <nav className="bg-indigo-600 text-white p-4 sticky top-0 z-50 shadow-lg">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <Activity className="w-6 h-6" />
          <span className="text-xl font-bold">HealthPredict AI</span>
        </div>
        
        <div className="flex-1 max-w-2xl mx-8">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-300" />
            </div>
            <input
              type="text"
              placeholder="Search medicines, symptoms, or scan medicine strip..."
              className="w-full pl-10 pr-32 py-2 rounded-lg bg-indigo-700 text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-white"
            />
            <div className="absolute inset-y-0 right-0 flex items-center space-x-2 pr-3">
              <button className="p-1 hover:bg-indigo-800 rounded-full">
                <Mic className="h-5 w-5" />
              </button>
              <button className="p-1 hover:bg-indigo-800 rounded-full">
                <Camera className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <button className="relative p-2 hover:bg-indigo-700 rounded-full">
            <Bell className="w-5 h-5" />
            <span className="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full"></span>
          </button>
          <button
            onClick={() => setActiveTab('profile')}
            className="p-2 hover:bg-indigo-700 rounded-full"
          >
            <UserCircle2 className="w-5 h-5" />
          </button>
        </div>
      </div>
      
      <div className="container mx-auto mt-4">
        <div className="flex space-x-4 overflow-x-auto pb-2">
          <NavButton
            icon={<Menu />}
            label="Prediction"
            active={activeTab === 'prediction'}
            onClick={() => setActiveTab('prediction')}
          />
          <NavButton
            icon={<Pills />}
            label="Medicines"
            active={activeTab === 'medicines'}
            onClick={() => setActiveTab('medicines')}
          />
          <NavButton
            icon={<Calendar />}
            label="Appointments"
            active={activeTab === 'appointments'}
            onClick={() => setActiveTab('appointments')}
          />
          <NavButton
            icon={<Apple />}
            label="Diet Plan"
            active={activeTab === 'diet'}
            onClick={() => setActiveTab('diet')}
          />
        </div>
      </div>
    </nav>
  );
}

function NavButton({ icon, label, active, onClick }: {
  icon: React.ReactNode;
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition ${
        active 
          ? 'bg-white text-indigo-600' 
          : 'text-white hover:bg-indigo-700'
      }`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}